package com.example.practicaconbind;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;

import com.example.practicaconbind.databinding.FragmentAltaurlBinding;
import com.example.practicaconbind.model.Url;
import com.example.practicaconbind.model.UrlViewModel;

public class AltaURLFragment extends Fragment {

    private FragmentAltaurlBinding binding;

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState


    ) {
        // creado e inflado ya
        binding = FragmentAltaurlBinding.inflate(inflater, container, false);

        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        EditText nombreEditext= binding.nombreP;
        EditText direccionEditecxt= binding.urlP;

        binding.alta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // recogemos los valores de editex
                Url  url = new Url(nombreEditext.getText().toString(),
                        direccionEditecxt.getText().toString(),0);

                //el provaider es donde quieres que se vea ese model
                UrlViewModel  urlViewModel= new ViewModelProvider(requireActivity()).get(UrlViewModel.class);
                urlViewModel.onClickAlta(url);
                NavHostFragment.findNavController(AltaURLFragment.this)
                        .navigate(R.id.action_altaURLFragment_to_listaURLFragment);
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
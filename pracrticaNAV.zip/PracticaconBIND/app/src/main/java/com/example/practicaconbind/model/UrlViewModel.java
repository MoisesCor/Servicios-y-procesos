package com.example.practicaconbind.model;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

public class UrlViewModel extends ViewModel {

    // esto es lo que es el controlador
    private MutableLiveData<List<Url>> listaUrl;
    private UrlReository urlReository;

    public UrlViewModel() {
        listaUrl = new  MutableLiveData<>();
        urlReository= new UrlReository();

    }

    public MutableLiveData<List<Url>> getListaUrl() {
        return listaUrl;
    }

    public void onClickAlta(Url url){
        urlReository.insert(url);
        //esto es que cada vez que se carga a la lista avise al repositorio para que se actualice
        listaUrl.postValue(urlReository.getUrls());
    }

    // caergaMOS LA LISTA INICIAL AL MAIN y en el main lo recargamos
    public void cargaInicial(){
        listaUrl.postValue(urlReository.getUrls());
    }
}

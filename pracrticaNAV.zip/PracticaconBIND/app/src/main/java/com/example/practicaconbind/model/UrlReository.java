package com.example.practicaconbind.model;

import java.util.ArrayList;
import java.util.List;

public class UrlReository {
    private ArrayList<Url> urls;

    public UrlReository(){
        urls=new ArrayList<>();
        urls.add(new Url("Tienda online","www.amazon.com",0));
        urls.add(new Url("Buscador favorito","www.google.com",3));
        urls.add(new Url("Educamadrid","www.educa.com",0));
    }

    public void insert(Url url){
    urls.add(url);
    }

    public List<Url> getUrls(){
        return urls;
    }
}

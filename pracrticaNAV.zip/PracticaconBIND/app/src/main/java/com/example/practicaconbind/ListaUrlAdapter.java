package com.example.practicaconbind;

import android.content.Context;
import android.os.Binder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.practicaconbind.databinding.UrlItemBinding;
import com.example.practicaconbind.model.Url;

import java.util.List;

public class ListaUrlAdapter extends ArrayAdapter {
    private Context ctx;
    private int layoutemplate;
    List<Url> urls;

    //creamosun binding
    UrlItemBinding binding;


    public ListaUrlAdapter(@NonNull Context context, int resource, @NonNull List objects) {
        super(context, resource, objects);
        ctx=context;
        layoutemplate=resource;
        urls=objects;// se podria poner arraylist y en ese caso castear
    }

    // crreamos un getvieww
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        binding = UrlItemBinding.inflate(LayoutInflater.from(ctx),parent,false);
        TextView  nombreTextview=binding.nombre;
        TextView direccionTexview=binding.direccion;
        TextView visitasTextview= binding.visitas;
        nombreTextview.setText(urls.get(position).getNombre());
        direccionTexview.setText(urls.get(position).getDireccion());
        visitasTextview.setText(""+urls.get(position).getVistas());

        // devuelveds la vista con el binding se hace así es como la vista
        return binding.getRoot();
    }
}

package com.example.practicaconbind.model;

public class Url {
    private String nombre;
    private  String direccion;
    private int vistas;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getVistas() {
        return vistas;
    }

    public void setVistas(int vistas) {
        this.vistas = vistas;
    }

    public Url(String nombre, String direccion, int vistas) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.vistas = vistas;
    }

    @Override
    public String toString() {
        return "Url{" +
                "nombre='" + nombre + '\'' +
                ", direccion='" + direccion + '\'' +
                ", vistas=" + vistas +
                '}';
    }
}

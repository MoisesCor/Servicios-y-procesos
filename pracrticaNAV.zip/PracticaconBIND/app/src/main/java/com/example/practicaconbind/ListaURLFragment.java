package com.example.practicaconbind;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;

import com.example.practicaconbind.databinding.FragmentListaurlsBinding;
import com.example.practicaconbind.databinding.FragmentListaurlsBinding;
import com.example.practicaconbind.model.UrlReository;
import com.example.practicaconbind.model.UrlViewModel;

public class ListaURLFragment extends Fragment {

    private FragmentListaurlsBinding binding;
    // nos definimos la clase repositori, que es donde creamos los elementos, es como antes que hacimaos las listas a pelo
    private UrlReository urlReository= new UrlReository();


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentListaurlsBinding.inflate(inflater, container, false);
        // con el baind recogemos asi la vista mucho más sencillo sin el r layaout
        ListView listaUrls=binding.listaURLs;
        // definimos adaptador y se lo asociamos al listview es como lo haciamos antiguamente
       /* ListaUrlAdapter listaUrlAdapter= new ListaUrlAdapter(getContext(),
                R.layout.url_item,urlReository.getUrls());
        listaUrls.setAdapter(listaUrlAdapter);*/

        // es lo mismo darle la vista esa, lo que hicimos en el alta
        /*Ahora a esa instancia le cargamos el adaptador al controlador*/
        UrlViewModel urlViewModel= new ViewModelProvider(requireActivity()).get(UrlViewModel.class);
        // nos subcribimos al data
        urlViewModel.getListaUrl().observe(getViewLifecycleOwner(),s->{
            ListaUrlAdapter listaUrlAdapter= new ListaUrlAdapter(getContext(),
                    R.layout.url_item,s);
            listaUrls.setAdapter(listaUrlAdapter);

        });
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}